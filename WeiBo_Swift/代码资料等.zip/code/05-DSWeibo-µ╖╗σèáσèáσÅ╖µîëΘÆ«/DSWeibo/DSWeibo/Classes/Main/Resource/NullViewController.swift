//
//  NullViewController.swift
//  XMGWeibo
//
//  Created by 李南江 on 15/8/31.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

import UIKit

class NullViewController: UIViewController {

    
}
