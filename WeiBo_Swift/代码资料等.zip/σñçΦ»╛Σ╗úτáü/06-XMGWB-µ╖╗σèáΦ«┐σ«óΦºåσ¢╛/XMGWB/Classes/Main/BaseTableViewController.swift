//
//  BaseTableViewController.swift
//  XMGWB
//
//  Created by 李南江 on 15/9/6.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

import UIKit

class BaseTableViewController: UITableViewController {
    // 定义变量保存用户是否登录
    var login:Bool = false
    var visitorView: VisitorView?
    override func loadView() {
         // 如果已经登录创建TableView, 如果没有登录创建访客视图
        login ? super.loadView() : setupVisitor()
    }
    
    /**
    创建访客视图
    */
    private func setupVisitor()
    {
        visitorView = VisitorView()
        view = visitorView
    }

}
